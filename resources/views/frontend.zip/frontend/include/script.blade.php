<script src="{{ asset('') }}asset/frontend/js/swiper-bundle.min.js"></script>
<script src="{{ asset('') }}asset/frontend/js/mixitup.min.js"></script>
<script src="{{ asset('') }}asset/frontend/js/script.js"></script>
<script>
</script>
