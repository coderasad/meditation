@extends('frontend.layouts.app')

@section('title', 'Events')


@section('content')
@include('frontend.pages.events.section.banner')
@include('frontend.pages.events.section.gellary')
@endsection