<section class="same-bg">
    <div class="container">
        <div class="same-bg-text tc">
            <h1 class="ps-700 c00 s38">Detox</h1>
            <ul class="d-flex align-items-center justify-content-center">
                <li><a href="index.html" class="ps-700 cff s18">Home</a></li>
                <li class="ps-700 cff s18">|</li>
                <li><a href="javascript:void(0)" class="ps-700 cb6 s18">Detox</a></li>
            </ul>
        </div>
    </div>
</section>