@extends('frontend.layouts.app')

@section('title', 'Sleep')

@section('content')
@include('frontend.pages.sleep.section.banner')
@include('frontend.pages.sleep.section.sleep-content')
@endsection