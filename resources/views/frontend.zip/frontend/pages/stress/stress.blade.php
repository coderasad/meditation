@extends('frontend.layouts.app')

@section('title', 'Stress')


@section('content')
@include('frontend.pages.stress.section.banner')
@include('frontend.pages.stress.section.stress-content')
@endsection