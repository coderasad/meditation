@extends('frontend.layouts.app')

@section('title', 'Living')

@section('content')
@include('frontend.pages.living.section.banner')
@include('frontend.pages.living.section.stress')
    
@endsection